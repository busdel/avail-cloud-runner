Real public cohort excerpt - OpenNeuro ds004392 (license CC0).
Source: https://openneuro.org/datasets/ds004392
Groups: PD-NC / PD-MCI / PDD (Parkinson's disease cognitive spectrum).
Features: Schaefer-100 connectivity summaries (full and partial
correlation, Fisher-z) computed with the AVAIL imaging adapter
(AFNI + nilearn); clinical block: Hoehn & Yahr stage, six cognitive
domain z-scores, and individual cognitive test scores.
Upload this folder (or its zip) to the AVAIL web platform, or run:
  avail-omics run-generic --data-root example_ds004392 --out results
This excerpt reproduces the ds004392 entry of the platform's external
validation section. Please cite the dataset:
https://doi.org/10.18112/openneuro.ds004392
