REAL-COHORT EXCERPT - de-identified
===================================

Source: the multi-site Parkinson's disease cohort of our companion
paper (HC / MCI / PDD). Participant identifiers were remapped to
S001..; no direct identifiers are included. Values are the real
measured features (no synthetic values).

De-identification for public use: participant IDs remapped; age
stored as 10-year midpoints; education stored in three bins
(<=8, 9-12, >12 coded 8/10/13); no names, sites, dates or other
direct/quasi identifiers are included.

Excerpt: up to 29 subjects per class (HC / MCI / PDD), stratified.

Modalities: fMRI network-connectivity summaries (real Schaefer
network names), stool 16S genera, saliva 16S genera (real genus
names). Shotgun msp-ID layers are not part of this excerpt.

Missing modalities reflect the original cohort (availability is
structural); no imputation was applied to these tables.

USAGE: shared for the AVAIL demo with the cohort PIs' permission.
Do not redistribute outside the platform without approval.
